% David Eriksson, 2019

printf('sdssd');
printf('sdssd\n');

printf('sdssd');
printf('sdssd\n');

printf('sdssd');
printf('sdssd\n');
